package com.api.controller;

import com.api.dto.NominaResponse;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/nomina/api")
public class NominaApiController {

    @GetMapping(value = "/{id}", produces = "application/json")
    public NominaResponse obtenerNomina(@PathVariable Long id) {
        NominaResponse nomina = new NominaResponse();
        nomina.setEmpleadoId(id);
        nomina.setNombre("Empleado #" + id);
        nomina.setSueldoBase(800.0);
        nomina.setBonos(150.0);
        nomina.setDescuentos(50.0);
        nomina.setSueldoNeto(900.0);
        return nomina;
    }
}
